package CurrencyConvert;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CurrencyConverter {

	private JFrame frame;
	private JTextField Amount;
	private JButton btnConvert;
	private JButton btnReset;
	private JButton btnExit;
	private JComboBox endBox;
	private JComboBox startBox;
	private JLabel lblResult;
	double result = 0.0;
	double input;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CurrencyConverter window = new CurrencyConverter();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CurrencyConverter() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCurrencyConvert = new JLabel("Currency Converter");
		lblCurrencyConvert.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCurrencyConvert.setBounds(129, 11, 203, 34);
		frame.getContentPane().add(lblCurrencyConvert);
		
		JLabel lblFrom = new JLabel("From:");
		lblFrom.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblFrom.setForeground(new Color(128, 0, 0));
		lblFrom.setBounds(23, 83, 98, 23);
		frame.getContentPane().add(lblFrom);
		
		JLabel lblTo = new JLabel("To:");
		lblTo.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblTo.setForeground(new Color(128, 0, 0));
		lblTo.setBounds(248, 87, 46, 14);
		frame.getContentPane().add(lblTo);
		
		JLabel lblAmount = new JLabel("Amount:");
		lblAmount.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAmount.setForeground(new Color(128, 0, 0));
		lblAmount.setBounds(129, 129, 86, 23);
		frame.getContentPane().add(lblAmount);
		//where user input number
		Amount = new JTextField();
		Amount.setBounds(190, 131, 104, 20);
		frame.getContentPane().add(Amount);
		Amount.setColumns(10);
		
		startBox = new JComboBox();
		startBox.setModel(new DefaultComboBoxModel(new String[] {"SELECT", "EUR", "USD", "NEP"}));
		startBox.setBounds(71, 84, 98, 22);
		frame.getContentPane().add(startBox);
		
		endBox = new JComboBox();
		endBox.setModel(new DefaultComboBoxModel(new String[] {"SELECT", "EUR", "USD", "NEP"}));
		endBox.setBounds(281, 84, 86, 22);
		frame.getContentPane().add(endBox);
		
		btnConvert = new JButton("Convert");
		btnConvert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent  arg0) {
				//button pressed convert
				try {
					//converting input string into a double
					input = Double.parseDouble(Amount.getText());
					//work with combo box
					
					//converting 1 EUR to USD. 1EUR is $1.17
					//combining the 2 box selection with in if statement
					if(startBox.getSelectedItem().equals("EUR")&& endBox.getSelectedItem().equals("EUR")) {
						lblResult.setText("Same currency unit");
					}
					if(startBox.getSelectedItem().equals("EUR")&& endBox.getSelectedItem().equals("USD")) {
						result = input*1.17;
						lblResult.setText(input+" EUR = $ "+result);	
					}
					if(startBox.getSelectedItem().equals("EUR")&& endBox.getSelectedItem().equals("NEP")) {
						result = input*139.49;
						lblResult.setText(input+" EUR = RUPEE "+result);	
					}
					if(startBox.getSelectedItem().equals("USD")&& endBox.getSelectedItem().equals("USD")) {
						lblResult.setText("Choose different currency unit");	
					}
					if(startBox.getSelectedItem().equals("USD")&& endBox.getSelectedItem().equals("EUR")) {
						result = input/1.17;
						lblResult.setText(input+" $ = EUR "+result);	
					}
					if(startBox.getSelectedItem().equals("USD")&& endBox.getSelectedItem().equals("NEP")) {
						result = input/119.69;
						lblResult.setText(input+" $ = RUPEE "+result);
					}
					if(startBox.getSelectedItem().equals("NEP")&& endBox.getSelectedItem().equals("EUR")) {
						result = input/139.49;
						lblResult.setText(input+" NEP = EUR "+result);
					}
					if(startBox.getSelectedItem().equals("NEP")&& endBox.getSelectedItem().equals("USD")) {
						result = input/1.17;
						lblResult.setText(input+" RUPEE = $ "+result);		
					}
					
					if(startBox.getSelectedItem().equals("NEP")&& endBox.getSelectedItem().equals("NEP")) {
						lblResult.setText("SAME CURRENCY UNIT");	
					}
					
				}catch (Exception e) {
					//warn user if input is invalid
					JOptionPane.showMessageDialog(frame, e.getMessage());
				}
				
			}
		});
		btnConvert.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnConvert.setForeground(new Color(0, 0, 128));
		btnConvert.setBounds(23, 178, 121, 23);
		frame.getContentPane().add(btnConvert);
		
		btnReset = new JButton("Reset");
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//reset everything back to default
				startBox.setSelectedIndex(0);
				endBox.setSelectedIndex(0);
				lblResult.setText("0.00");
				Amount.setText("");
			}
		});
		btnReset.setBounds(324, 179, 89, 23);
		frame.getContentPane().add(btnReset);
		
		btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//exit app
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnExit.setBounds(324, 213, 89, 23);
		frame.getContentPane().add(btnExit);
		
		lblResult = new JLabel("Result Here!");
		lblResult.setForeground(new Color(50, 205, 50));
		lblResult.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblResult.setBounds(23, 218, 192, 23);
		frame.getContentPane().add(lblResult);
	}
}
